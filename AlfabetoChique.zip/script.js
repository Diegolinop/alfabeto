function soundPlay(letter){
    var audio = new Audio();
    audio.src = letter+".mp3"
    audio.play();
    console.log("Playing now: "+letter)
    document.getElementById('display-letter').innerHTML = letter;
}